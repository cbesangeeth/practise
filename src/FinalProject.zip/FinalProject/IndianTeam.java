package FinalProject;

import java.util.Date;

public class IndianTeam extends CricketPlayer {


    public IndianTeam(String name, Integer age, Date birthDate, String gender, String playerType, Integer inningPlayed, Integer runsScored, Integer runsGiven, Integer ballsFaced, Integer ballsBowled) {
        super(name, age, birthDate, gender, playerType, inningPlayed, runsScored, runsGiven, ballsFaced, ballsBowled);
    }
}
